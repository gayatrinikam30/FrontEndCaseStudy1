import React, { useState } from 'react';
import { Button, Form, Container, ListGroup } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const AdminPanel = () => {
  const [profiles, setProfiles] = useState([]);
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    description: '',
    address: '',
    latitude: '',
    longitude: '',
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.id) {
      // Edit existing profile
      setProfiles(
        profiles.map((profile) =>
          profile.id === formData.id ? formData : profile
        )
      );
    } else {
      // Add new profile
      setProfiles([...profiles, { ...formData, id: Date.now() }]);
    }
    setFormData({ id: '', name: '', description: '', address: '', latitude: '', longitude: '' });
  };

  const handleEdit = (profile) => {
    setFormData(profile);
  };

  const handleDelete = (id) => {
    setProfiles(profiles.filter(profile => profile.id !== id));
  };

  return (
    <Container>
      <h2>Admin Panel- Manage Profiles</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formBasicName">
          <Form.Label>Name</Form.Label>
          <Form.Control
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formBasicDescription">
          <Form.Label>Description</Form.Label>
          <Form.Control
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formBasicAddress">
          <Form.Label>Address</Form.Label>
          <Form.Control
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formBasicLatitude">
          <Form.Label>Latitude</Form.Label>
          <Form.Control
            type="number"
            name="latitude"
            value={formData.latitude}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formBasicLongitude">
          <Form.Label>Longitude</Form.Label>
          <Form.Control
            type="number"
            name="longitude"
            value={formData.longitude}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Button variant="primary" type="submit">
          {formData.id ? 'Update Profile' : 'Add Profile'}
        </Button>
      </Form>

      <h3 className="mt-4">Profile List</h3>
      <ListGroup>
        {profiles.map((profile) => (
          <ListGroup.Item key={profile.id} className="d-flex justify-content-between align-items-center">
            {profile.name}
            <div>
              <Button variant="warning" onClick={() => handleEdit(profile)} className="me-2">
                Edit
              </Button>
              <Button variant="danger" onClick={() => handleDelete(profile.id)}>
                Delete
              </Button>
            </div>
          </ListGroup.Item>
        ))}
      </ListGroup>
    </Container>
  );
};

export default AdminPanel;
