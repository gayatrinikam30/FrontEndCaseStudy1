import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const ProfileDetails = ({ profiles }) => {
  const { id } = useParams();
  const profile = profiles.find(p => p.id === parseInt(id));

  useEffect(() => {
    if (!profile) return; // Early return if profile is undefined

    const map = L.map('map').setView([profile.latitude, profile.longitude], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker([profile.latitude, profile.longitude]).addTo(map)
      .bindPopup(`${profile.name}`)
      .openPopup();

    return () => {
      map.remove(); // Clean up the map when the component unmounts
    };
  }, [profile]);

  if (!profile) return <div>Profile not found!</div>; // Handle missing profile

  return (
    <div>
      <h2>{profile.name}</h2>
      <img src={profile.image} alt={profile.name} style={{ maxWidth: '200px', marginBottom: '20px' }} />
      <p><strong>Description:</strong> {profile.description}</p>
      <p><strong>Address:</strong> {profile.address}</p>
      <p><strong>Contact:</strong> {profile.contact}</p>
      <p><strong>Interests:</strong> {profile.interests}</p>

      {/* Map for profile's location */}
      <div id="map" style={{ height: '400px', width: '100%', marginTop: '20px' }}></div>
    </div>
  );
};

export default ProfileDetails;
