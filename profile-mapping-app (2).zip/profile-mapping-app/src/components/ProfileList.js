import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, Button, Container, Row, Col, Form } from 'react-bootstrap';
import MapComponent from './MapComponent'; // Adjust the path if necessary
import './ProfileList.css'; // Optional for styling

const ProfileList = () => {
  const [profiles] = useState([
    { 
      id: 1, 
      name: 'John Doe', 
      image: 'https://via.placeholder.com/150', 
      description: 'Software Engineer', 
      address: 'New York, NY', 
      latitude: 40.7128, 
      longitude: -74.0060, 
      contact: 'johndoe@example.com', 
      interests: 'Coding, Reading' 
    },
    { 
      id: 2, 
      name: 'Jane Smith', 
      image: 'https://via.placeholder.com/150', 
      description: 'Data Scientist', 
      address: 'San Francisco, CA', 
      latitude: 37.7749, 
      longitude: -122.4194, 
      contact: 'janesmith@example.com', 
      interests: 'AI, Hiking' 
    },
    // Add more profiles here
  ]);

  const [selectedProfile, setSelectedProfile] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredProfiles, setFilteredProfiles] = useState(profiles);

  // Handle search and filter
  const handleSearch = (event) => {
    const searchTerm = event.target.value.toLowerCase();
    setSearchTerm(searchTerm);

    // Filter profiles based on search term
    const filtered = profiles.filter(profile =>
      profile.name.toLowerCase().includes(searchTerm) ||
      profile.address.toLowerCase().includes(searchTerm) ||
      profile.description.toLowerCase().includes(searchTerm)
    );

    setFilteredProfiles(filtered);
  };

  // Handle map summary click
  const handleSummaryClick = (profile) => {
    setSelectedProfile(profile);
  };

  return (
    <div className="profile-list">
      <Container>
        {/* Search Bar */}
        <Form.Group controlId="searchProfile" className="mb-4">
          <Form.Control
            type="text"
            placeholder="Search profiles by name, location, or description"
            value={searchTerm}
            onChange={handleSearch}
          />
        </Form.Group>

        {/* Profiles List */}
        <Row>
          {filteredProfiles.map(profile => (
            <Col md={4} key={profile.id} className="mb-4">
              <Card style={{ width: '100%' }}>
                <Card.Img variant="top" src={profile.image} />
                <Card.Body>
                  <Card.Title>{profile.name}</Card.Title>
                  <Card.Text>{profile.description}</Card.Text>
                  <Card.Text><small>{profile.address}</small></Card.Text>
                  <Card.Text><small><strong>Contact:</strong> {profile.contact}</small></Card.Text>
                  <Card.Text><small><strong>Interests:</strong> {profile.interests}</small></Card.Text>
                  <Link to={`/profile/${profile.id}`}>
                    <Button variant="primary" className="me-2">View Profile</Button>
                  </Link>
                  <Button variant="info" onClick={() => handleSummaryClick(profile)}>Summary</Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        {/* Conditionally Render MapComponent if a profile is selected */}
        {selectedProfile && (
          <MapComponent profile={selectedProfile} onClose={() => setSelectedProfile(null)} />
        )}
      </Container>
    </div>
  );
};

export default ProfileList;
