import React from 'react';
import ProfileList from './ProfileList'; // Assuming this is your profile listing page

const Home = () => {
  return (
    <div>
      <h1>Home Page</h1>
      <ProfileList /> {/* Render the ProfileList component */}
    </div>
  );
};

export default Home;
