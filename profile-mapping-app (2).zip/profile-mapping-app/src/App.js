import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ProfileList from './components/ProfileList';
import ProfileDetails from './components/ProfileDetails'; 
import AdminPanel from './components/AdminPanel';
import AddProfile from './components/AddProfile';
import 'leaflet/dist/leaflet.css'; // Ensure this is added to your project
import './App.css'; // Or wherever your global stylesheet is located
import Header from './components/Header';

const App = () => {
  const [profiles, setProfiles] = useState([
    { id: 1, name: 'John Doe', image: 'https://via.placeholder.com/150', description: 'Software Engineer', address: 'New York, NY', latitude: 40.7128, longitude: -74.0060, contact: 'johndoe@example.com', interests: 'Coding, Reading' },
    { id: 2, name: 'Jane Smith', image: 'https://via.placeholder.com/150', description: 'Data Scientist', address: 'San Francisco, CA', latitude: 37.7749, longitude: -122.4194, contact: 'janesmith@example.com', interests: 'AI, Hiking' }
  ]);

  // Function to add a new profile
  const addProfile = (newProfile) => {
    setProfiles((prevProfiles) => [...prevProfiles, newProfile]);
  };

  return (
    <Router>
      <Header />
      <Routes>
        {/* Home page listing profiles */}
        <Route path="/" element={<ProfileList profiles={profiles} />} />

        {/* Profile details page */}
        <Route 
          path="/profile/:id" 
          element={<ProfileDetails profiles={profiles} />} 
        />

        {/* Admin panel (you can customize this component) */}
        <Route path="/admin" element={<AdminPanel />} />

        {/* Page for adding new profiles */}
        <Route path="/add" element={<AddProfile onAddProfile={addProfile} />} />
      </Routes>
    </Router>
  );
};

export default App;
